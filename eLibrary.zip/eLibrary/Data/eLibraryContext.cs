﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using eLibrary.Models;

namespace eLibrary.Data
{
    public class eLibraryContext : DbContext
    {
        public eLibraryContext (DbContextOptions<eLibraryContext> options)
            : base(options)
        {
        }

        public DbSet<eLibrary.Models.ContactUs> ContactUs { get; set; }

        
    }
}
