﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NCSeLibraryMVC.Data;
using NCSeLibraryMVC.Models;

namespace NCSeLibraryMVC.Controllers
{
    public class FavouritesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FavouritesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Favourites
        public async Task<IActionResult> Catalogue()
        {
            // string Id_Of_AspUser = ExtensionMethods.getUserId(this.User);
            //   int userId = int.Parse(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);



            // var User = await _context.Users.SingleOrDefaultAsync(m => m.Id == Id_Of_AspUser);

            if (User == null)
            {
                return NotFound();
            }

            //   var cat = await _context.Favourites.SingleOrDefaultAsync(n => n.UserID.Equals(User.Id));
            return View(await _context.Favourites.ToListAsync());
        }

        //        [HttpPost]
        public async Task<IActionResult> AddToFavourites(int id)
        {
            //  var a = HttpContext.User.Claims

            var book = await _context.Books
                .FirstOrDefaultAsync(m => m.Id == id);

            Favourites favourites = new Favourites
            {
                UserID = 1,
                BookID = id,
                Title = book.Title,
                Info = book.info,
                Url = book.Url,
                ImgFile = book.ImgFile,
                Author = book.Author
            };

            await _context.Favourites.AddAsync(favourites);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Catalogue));
        }

        // GET: Favourites/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var favourites = await _context.Favourites
                .FirstOrDefaultAsync(m => m.Id == id);
            if (favourites == null)
            {
                return NotFound();
            }

            return View(favourites);
        }

        // GET: Favourites/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Favourites/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Url,Author")] Favourites favourites)
        {
            if (ModelState.IsValid)
            {
                _context.Add(favourites);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(favourites);
        }

        // GET: Favourites/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var favourites = await _context.Favourites.FindAsync(id);
            if (favourites == null)
            {
                return NotFound();
            }
            return View(favourites);
        }

        // POST: Favourites/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Url,Author")] Favourites favourites)
        {
            if (id != favourites.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(favourites);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FavouritesExists(favourites.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(favourites);
        }

        // GET: Favourites/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var favourites = await _context.Favourites
                .FirstOrDefaultAsync(m => m.Id == id);
            if (favourites == null)
            {
                return NotFound();
            }

            return View(favourites);
        }

        // POST: Favourites/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var favourites = await _context.Favourites.FindAsync(id);
            _context.Favourites.Remove(favourites);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Catalogue));
        }

        private bool FavouritesExists(int id)
        {
            return _context.Favourites.Any(e => e.Id == id);
        }
    }
}
