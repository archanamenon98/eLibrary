﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NCSeLibraryMVC.Models
{
    public class Favourites
    {
        [Key]
        public int Id { get; set; }

        public int BookID { get; set; }

        public int UserID { get; set; }
        public string Title { get; set; }
        public string Info { get; set; }
        public string Url { get; set; }
        public string Category { get; set; }
        public string Author { get; set; }
        public string ImgFile { get; set; }

    }
}
