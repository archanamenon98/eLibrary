﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using NCSeLibraryMVC.Models;

namespace NCSeLibraryMVC.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<NCSeLibraryMVC.Models.Books> Books { get; set; }
        public DbSet<NCSeLibraryMVC.Models.ContactUs> ContactUs { get; set; }
        public DbSet<NCSeLibraryMVC.Models.Favourites> Favourites { get; set; }
    }
}
